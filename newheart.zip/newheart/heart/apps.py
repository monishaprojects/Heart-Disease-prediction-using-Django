from django.apps import AppConfig


class HeartConfig(AppConfig):
    name = 'heart'
